package combo.miltan.arafat.personalassistant;

interface ITelephony {
    void endCall();
}

